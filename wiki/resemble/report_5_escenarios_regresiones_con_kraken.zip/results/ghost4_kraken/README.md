#### Carpeta de pruebas de ghostv4 para la  comparacion de imagenes
