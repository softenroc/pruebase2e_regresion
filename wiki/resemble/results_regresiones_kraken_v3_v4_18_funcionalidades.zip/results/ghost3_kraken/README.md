#### Carpeta de pruebas de ghostv3 para la  comparacion de imagenes
